const form = document.getElementById("settingsForm");
const saveMsg = document.getElementById("saveMsg");
const statusBox = document.getElementById("statusBox");
const statusBody = document.getElementById("statusBody");

const fields = ["token", "owner", "repo", "branch"];

function load() {
  chrome.storage.sync.get(fields, (values) => {
    fields.forEach((f) => {
      if (values[f]) document.getElementById(f).value = values[f];
    });
  });

  chrome.storage.local.get(["lastStatus"], ({ lastStatus }) => {
    if (!lastStatus) return;
    statusBox.style.display = "block";
    statusBox.className = "status " + (lastStatus.ok ? "ok" : "err");
    const when = lastStatus.time ? new Date(lastStatus.time).toLocaleString() : "";
    if (lastStatus.ok) {
      statusBody.innerHTML = `<span class="dot"></span>${escapeHtml(lastStatus.title)}<br><span style="color:var(--muted)">${when}</span>`;
    } else {
      statusBody.innerHTML = `<span class="dot"></span>Failed: ${escapeHtml(lastStatus.message || "unknown error")}`;
    }
  });
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const values = {};
  fields.forEach((f) => (values[f] = document.getElementById(f).value.trim()));
  if (!values.branch) values.branch = "main";

  chrome.storage.sync.set(values, () => {
    saveMsg.textContent = "Saved.";
    setTimeout(() => (saveMsg.textContent = ""), 1800);
  });
});

load();
