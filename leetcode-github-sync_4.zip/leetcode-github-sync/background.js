const LANG_EXTENSIONS = {
  "python3": "py",
  "python": "py",
  "java": "java",
  "c++": "cpp",
  "c": "c",
  "c#": "cs",
  "javascript": "js",
  "typescript": "ts",
  "php": "php",
  "swift": "swift",
  "kotlin": "kt",
  "dart": "dart",
  "golang": "go",
  "ruby": "rb",
  "scala": "scala",
  "rust": "rs",
  "racket": "rkt",
  "erlang": "erl",
  "elixir": "ex",
  "mysql": "sql",
  "mssql": "sql",
  "oraclesql": "sql",
  "postgresql": "sql",
};

console.log("[LGS] background.js service worker loaded");

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type !== "PUSH_TO_GITHUB") return;
  console.log("[LGS] background received PUSH_TO_GITHUB for", message.payload.title);
  pushSubmission(message.payload)
    .then(() => {
      console.log("[LGS] push succeeded:", message.payload.title);
      sendResponse({ ok: true });
    })
    .catch((err) => {
      console.error("[LGS] push failed", err);
      recordStatus({ ok: false, message: err.message, title: message.payload.title });
      sendResponse({ ok: false, error: err.message });
    });
  return true; // keep the message channel open for the async response
});

async function pushSubmission(payload) {
  const settings = await getSettings();
  if (!settings.token || !settings.owner || !settings.repo) {
    throw new Error("Extension isn't configured yet \u2014 open the popup and add your GitHub token/repo.");
  }

  const ext = LANG_EXTENSIONS[payload.lang.toLowerCase()] || "txt";
  const safeSlug = payload.titleSlug;
  const dir = payload.difficulty || "Unsorted";
  const path = `${dir}/${payload.questionId}-${safeSlug}.${ext}`;
  const branch = settings.branch || "main";

  const header = buildFileHeader(payload, ext);
  const fileContent = `${header}\n${payload.code}\n`;

  await upsertFile({
    token: settings.token,
    owner: settings.owner,
    repo: settings.repo,
    branch,
    path,
    content: fileContent,
    message: `[LeetCode] ${payload.questionId}. ${payload.title} (${payload.difficulty})`,
  });

  await updateReadme(settings, payload, path).catch((e) =>
    console.warn("[LeetCode\u2192GitHub Sync] README update skipped:", e.message)
  );

  recordStatus({ ok: true, title: payload.title, path, time: Date.now() });
}

function buildFileHeader(payload, ext) {
  const commentStyles = {
    py: "#", rb: "#", sql: "--",
  };
  const c = commentStyles[ext] || "//";
  return [
    `${c} ${payload.questionId}. ${payload.title} (${payload.difficulty})`,
    `${c} ${payload.url}`,
    `${c} Runtime: ${payload.runtime || "n/a"}  Memory: ${payload.memory || "n/a"}`,
  ].join("\n");
}

async function upsertFile({ token, owner, repo, branch, path, content, message }) {
  const apiUrl = `https://api.github.com/repos/${owner}/${repo}/contents/${encodeURIComponent(path)}`;

  let sha;
  const getRes = await fetch(`${apiUrl}?ref=${encodeURIComponent(branch)}`, {
    headers: authHeaders(token),
  });
  if (getRes.ok) {
    const existing = await getRes.json();
    sha = existing.sha;
  } else if (getRes.status !== 404) {
    const err = await getRes.json().catch(() => ({}));
    throw new Error(err.message || `GitHub GET failed (${getRes.status})`);
  }

  const body = { message, content: toBase64(content), branch };
  if (sha) body.sha = sha;

  const putRes = await fetch(apiUrl, {
    method: "PUT",
    headers: { ...authHeaders(token), "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

  if (!putRes.ok) {
    const err = await putRes.json().catch(() => ({}));
    throw new Error(err.message || `GitHub PUT failed (${putRes.status})`);
  }

  return putRes.json();
}

async function updateReadme(settings, payload, solutionPath) {
  const { token, owner, repo, branch } = settings;
  const apiUrl = `https://api.github.com/repos/${owner}/${repo}/contents/README.md`;
  const branchQ = encodeURIComponent(branch || "main");

  let existingText = "";
  let sha;
  const getRes = await fetch(`${apiUrl}?ref=${branchQ}`, { headers: authHeaders(token) });
  if (getRes.ok) {
    const data = await getRes.json();
    sha = data.sha;
    existingText = fromBase64(data.content.replace(/\n/g, ""));
  } else if (getRes.status !== 404) {
    return; // don't block the solution push over a README issue
  }

  const marker = "<!-- leetcode-github-sync:table -->";
  const row = `| [${payload.questionId}. ${payload.title}](${payload.url}) | ${payload.difficulty} | ${payload.lang} | [\`${solutionPath}\`](${solutionPath}) |`;

  let newText;
  if (existingText.includes(marker)) {
    if (existingText.includes(solutionPath)) {
      // already logged, nothing to change
      return;
    }
    newText = existingText.replace(marker, `${marker}\n${row}`);
  } else {
    const header = [
      "# LeetCode Solutions",
      "",
      "_Synced automatically by LeetCode \u2192 GitHub Sync._",
      "",
      "| Problem | Difficulty | Language | Solution |",
      "|---|---|---|---|",
      marker,
      row,
    ].join("\n");
    newText = existingText ? `${existingText}\n\n${header}` : header;
  }

  const body = {
    message: `Update README: ${payload.title}`,
    content: toBase64(newText),
    branch: branch || "main",
  };
  if (sha) body.sha = sha;

  await fetch(apiUrl, {
    method: "PUT",
    headers: { ...authHeaders(token), "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
}

function authHeaders(token) {
  return {
    Authorization: `token ${token}`,
    Accept: "application/vnd.github+json",
  };
}

function toBase64(str) {
  const bytes = new TextEncoder().encode(str);
  let binary = "";
  bytes.forEach((b) => (binary += String.fromCharCode(b)));
  return btoa(binary);
}

function fromBase64(b64) {
  const binary = atob(b64);
  const bytes = Uint8Array.from(binary, (c) => c.charCodeAt(0));
  return new TextDecoder().decode(bytes);
}

function getSettings() {
  return new Promise((resolve) => {
    chrome.storage.sync.get(["token", "owner", "repo", "branch"], resolve);
  });
}

function recordStatus(status) {
  chrome.storage.local.set({ lastStatus: status });
}
