// Runs in the PAGE's own JS context (world: "MAIN"), so it can see the
// fetch/XHR calls LeetCode's own React app makes. It never touches your
// GitHub token — it only detects "Accepted" and hands the submission id
// back to content.js via window.postMessage.
(function () {
  const CHECK_URL_RE = /\/submissions\/detail\/(\d+)\/(?:v2\/)?check\/?/;
  console.log("[LGS] inject.js loaded \u2014 watching for submissions");

  function announceAccepted(submissionId) {
    console.log("[LGS] Accepted detected, submissionId =", submissionId);
    window.postMessage(
      { source: "leetcode-github-sync", type: "ACCEPTED", submissionId },
      "*"
    );
  }

  // --- patch fetch ---
  const origFetch = window.fetch;
  window.fetch = async function (...args) {
    const response = await origFetch.apply(this, args);
    try {
      const url = typeof args[0] === "string" ? args[0] : args[0]?.url;
      const match = url && url.match(CHECK_URL_RE);
      if (match) {
        response
          .clone()
          .json()
          .then((data) => {
            console.log("[LGS] check/ response:", data && data.state, data && data.status_msg);
            if (data && data.state === "SUCCESS" && data.status_msg === "Accepted") {
              announceAccepted(match[1]);
            }
          })
          .catch((e) => console.log("[LGS] check/ parse failed", e));
      }
    } catch (e) {
      /* ignore */
    }
    return response;
  };

  // --- patch XHR (LeetCode has used both over the years) ---
  const origOpen = XMLHttpRequest.prototype.open;
  const origSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this.__lgs_url = url;
    return origOpen.call(this, method, url, ...rest);
  };

  XMLHttpRequest.prototype.send = function (...args) {
    this.addEventListener("load", function () {
      try {
        const match = this.__lgs_url && this.__lgs_url.match(CHECK_URL_RE);
        if (match) {
          const data = JSON.parse(this.responseText);
          if (data && data.state === "SUCCESS" && data.status_msg === "Accepted") {
            announceAccepted(match[1]);
          }
        }
      } catch (e) {
        /* ignore */
      }
    });
    return origSend.apply(this, args);
  };
})();
