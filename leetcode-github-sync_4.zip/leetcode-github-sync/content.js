// Runs in the isolated content-script world (has access to chrome.runtime,
// shares leetcode.com cookies for same-origin requests).
let lastHandledSubmissionId = null;
console.log("[LGS] content.js loaded");

// Inject inject.js into the page's REAL js context so it can patch the
// actual fetch/XHR the React app uses (an isolated-world patch would only
// affect a copy nobody calls).
(function injectPageScript() {
  const s = document.createElement("script");
  s.src = chrome.runtime.getURL("inject.js");
  s.onload = function () {
    console.log("[LGS] inject.js script tag loaded into page context");
    this.remove();
  };
  (document.head || document.documentElement).appendChild(s);
})();

window.addEventListener("message", (event) => {
  if (event.source !== window) return;
  const data = event.data;
  if (!data || data.source !== "leetcode-github-sync" || data.type !== "ACCEPTED") return;
  if (!data.submissionId || data.submissionId === lastHandledSubmissionId) return;

  console.log("[LGS] content.js received ACCEPTED message for", data.submissionId);
  lastHandledSubmissionId = data.submissionId;
  handleAccepted(data.submissionId);
});

async function handleAccepted(submissionId) {
  try {
    const details = await fetchSubmissionDetails(submissionId);
    if (!details) {
      console.log("[LGS] GraphQL returned no submissionDetails for", submissionId);
      return;
    }
    console.log("[LGS] fetched details, sending to background:", details.question.title);

    chrome.runtime.sendMessage({
      type: "PUSH_TO_GITHUB",
      payload: {
        submissionId,
        title: details.question.title,
        titleSlug: details.question.titleSlug,
        questionId: details.question.questionId,
        difficulty: details.question.difficulty,
        lang: details.lang.name,
        code: details.code,
        runtime: details.runtimeDisplay,
        memory: details.memoryDisplay,
        url: `https://leetcode.com/problems/${details.question.titleSlug}/`,
      },
    });
  } catch (e) {
    console.error("[LeetCode\u2192GitHub Sync] failed to fetch submission details", e);
  }
}

async function fetchSubmissionDetails(submissionId) {
  const query = `
    query submissionDetails($submissionId: Int!) {
      submissionDetails(submissionId: $submissionId) {
        code
        runtimeDisplay
        memoryDisplay
        lang { name verboseName }
        question {
          questionId
          titleSlug
          title
          difficulty
        }
      }
    }
  `;

  const res = await fetch("https://leetcode.com/graphql", {
    method: "POST",
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      query,
      variables: { submissionId: Number(submissionId) },
    }),
  });

  if (!res.ok) throw new Error(`GraphQL request failed: ${res.status}`);
  const json = await res.json();
  return json?.data?.submissionDetails || null;
}
